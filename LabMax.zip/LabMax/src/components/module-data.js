export const data = [
  {
    id: 1,
    name: "Max",
    birth: "2004-02-05",
    eyes: "szary",
    rating: 9
  },
  {
    id: 2,
    name: "Kuba",
    birth: "2002-06-24",
    eyes: "niebieski",
    rating: 0
  },
  {
    id: 3,
    name: "Mateusz",
    birth: "1943-09-22",
    eyes: "czarny",
    rating: 4
  },
  {
    id: 4,
    name: "Małgorzata",
    birth: "2002-06-24",
    eyes: "czarny",
    rating: 0
  },
  {
    id: 5,
    name: "Mikołaj",
    birth: "2004-02-05",
    eyes: "szary",
    rating: 2
  },
  {
    id: 6,
    name: "Cezary",
    birth: "2004-02-05",
    eyes: "czarny",
    rating: 7
  },
  {
    id: 7,
    name: "Andrzej",
    birth: "1980-05-25",
    eyes: "zielony",
    rating: 3
  },
  {
    id: 8,
    name: "Simba",
    birth: "2004-02-05",
    eyes: "szary",
    rating: 10
  },
];