import React from 'react';

function SimpleLayout({ children }) {
  return (
    <div>
      <div>{children}</div>
    </div>
  );
}
export default SimpleLayout