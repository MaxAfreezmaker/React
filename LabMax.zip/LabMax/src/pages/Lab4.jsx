import { Link } from "react-router-dom";

function Lab4(){
    return(
        <>
        <Link to="/lab4/add">Dodaj obiekt</Link>
    
        </>
    )
}

export default Lab4;